تعليمات إضافة صور الموقع قبل رفعه إلى Cloudflare Pages

ضع صور المعرض داخل هذا المجلد:
assets/

الأسماء المطلوبة التي يتوقعها الموقع:
showroom-1.png
showroom-2.png
showroom-3.png
showroom-4.png
showroom-5.png
showroom-6.png
showroom-7.png
showroom-8.png
showroom-10.png
showroom-11.png
showroom-12.png
showroom-13.png
showroom-14.png
showroom-15.png
showroom-16.png
showroom-17.png
showroom-18.png
showroom-19.png
showroom-20.png
showroom-21.png
showroom-22.png

ملاحظات:
- يفضل صيغة PNG كما في الأسماء أعلاه.
- إذا كانت صورك JPG، إما غيّر أسماءها/صيغتها إلى PNG، أو أخبرني لأعدل الملف على JPG.
- صورة Hero ستستخدم صور showroom تلقائيًا إذا كانت موجودة.
- إذا لم تكن صور showroom موجودة، سيستعمل الموقع الصور الاحتياطية الموجودة مثل home-hero.jpg.
